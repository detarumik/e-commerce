// Sample featured products data
const featuredProducts = [
    { id: 'featured1', name: "Hydrating Serum", price: 2500 },
    { id: 'featured2', name: "Glow Foundation", price: 1800 },
    { id: 'featured3', name: "Matte Lipstick", price: 1200 }
  ];
  
  // Add to cart function for featured products
  function addFeaturedToCart(productId) {
    const product = featuredProducts.find(p => p.id === productId);
    
    // Get existing cart from localStorage
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    
    // Check if product already exists in cart
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cart.push({
        id: product.id,
        name: product.name,
        price: product.price,
        quantity: 1
      });
    }
    
    // Save updated cart to localStorage
    localStorage.setItem("cart", JSON.stringify(cart));
    alert(`${product.name} added to your cart!`);
  }