// Sample Products
// Sample Products
const products = [
  { id: 1, name: "Moisturizing Shampoo", price: 1299, category: "Haircare", image: "shampoo.jpg" },
  { id: 2, name: "Smoothing Conditioner", price: 1499, category: "Haircare", image: "conditioner.jpg" },
  { id: 3, name: "Argan Hair Oil", price: 1899, category: "Haircare", image: "hair-oil.jpg" },
  { id: 4, name: "Matte Lipstick", price: 999, category: "Makeup", image: "product3.jpeg" },
  { id: 5, name: "Eyeshadow Palette", price: 2599, category: "Makeup", image: "eyeshadow.jpg" },
  { id: 6, name: "Liquid Foundation", price: 1999, category: "Makeup", image: "foundation.jpg" },
  { id: 7, name: "Hydrating Body Lotion", price: 1099, category: "Body", image: "body-lotion.jpg" },
  { id: 8, name: "Exfoliating Body Scrub", price: 1599, category: "Body", image: "body-scrub.jpg" },
  { id: 9, name: "Daily Moisturizer", price: 1299, category: "Skincare", image: "moisturizer.jpg" },
  { id: 10, name: "Brightening Serum", price: 2299, category: "Skincare", image: "serum.jpg" },
];

let filteredProducts = [...products]; // Copy of products for filtering
let cart = []; // Shopping cart

// Load products into the carousel
function loadProducts() {
  const carouselTrack = document.getElementById("carouselTrack");
  carouselTrack.innerHTML = "";
  filteredProducts.forEach((product) => {
    const productCard = document.createElement("div");
    productCard.classList.add("product-card");
    productCard.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <h3>${product.name}</h3>
      <p>Kshs ${product.price.toLocaleString()}</p>
      <button onclick="addToCart(${product.id})">Add to Cart</button>
    `;
    carouselTrack.appendChild(productCard);
  });
}

// Filter products by category
function filterProducts() {
  const category = document.getElementById("categoryFilter").value;
  filteredProducts = category === "all" ? [...products] : products.filter((p) => p.category === category);
  loadProducts();
}

// Sort products by selected criteria
function sortProducts() {
  const sortOrder = document.getElementById("sortOrder").value;
  filteredProducts.sort((a, b) => {
    if (sortOrder === "name") return a.name.localeCompare(b.name);
    if (sortOrder === "priceAsc") return a.price - b.price;
    if (sortOrder === "priceDesc") return b.price - a.price;
  });
  loadProducts();
}

// Add product to cart
function addToCart(productId) {
  const product = products.find(p => p.id === productId);
  
  // Get existing cart from localStorage
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  
  // Check if product already exists in cart
  const existingItem = cart.find(item => item.id === productId);
  
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1
    });
  }
  
  // Save updated cart to localStorage
  localStorage.setItem("cart", JSON.stringify(cart));
  alert(`${product.name} added to your cart!`);
}

// Scroll carousel left
function scrollLeft() {
  const carouselTrack = document.getElementById("carouselTrack");
  carouselTrack.scrollLeft -= 300;
}

// Scroll carousel right
function scrollRight() {
  const carouselTrack = document.getElementById("carouselTrack");
  carouselTrack.scrollLeft += 300;
}

// Initialize the page
loadProducts();