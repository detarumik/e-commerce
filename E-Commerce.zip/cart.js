const cart = JSON.parse(localStorage.getItem("cart")) || [];
const cartItems = document.getElementById("cartItems");
const totalPrice = document.getElementById("totalPrice");
const checkoutButton = document.getElementById("checkoutButton");
const paymentGateway = document.getElementById("paymentGateway");
const paymentForm = document.getElementById("paymentForm");
const successMessage = document.getElementById("successMessage");
const mpesaFields = document.getElementById("mpesaFields");
const cardFields = document.getElementById("cardFields");

// Render Cart Items
function renderCart() {
  cartItems.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    const itemDiv = document.createElement("div");
    itemDiv.classList.add("cart-item");
    itemDiv.innerHTML = `
      <h3>${item.name}</h3>
      <p>Price: Ksh ${item.price.toFixed(2)}</p>
      <div class="quantity-controls">
        <button onclick="updateQuantity(${index}, -1)">-</button>
        <span>${item.quantity}</span>
        <button onclick="updateQuantity(${index}, 1)">+</button>
      </div>
    `;
    cartItems.appendChild(itemDiv);
    total += item.price * item.quantity;
  });

  totalPrice.textContent = `Ksh ${total.toFixed(2)}`;
}

// Update Quantity
function updateQuantity(index, change) {
  cart[index].quantity += change;
  if (cart[index].quantity <= 0) {
    cart.splice(index, 1);
  }
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

// Show Payment Gateway
checkoutButton.addEventListener("click", () => {
  paymentGateway.classList.remove("hidden");
});

// Handle Payment Method Fields
paymentForm.addEventListener("change", (e) => {
  if (e.target.value === "mpesa") {
    mpesaFields.classList.remove("hidden");
    cardFields.classList.add("hidden");
  } else if (e.target.value === "card") {
    cardFields.classList.remove("hidden");
    mpesaFields.classList.add("hidden");
  } else {
    mpesaFields.classList.add("hidden");
    cardFields.classList.add("hidden");
  }
});

// Handle Payment Submission
paymentForm.addEventListener("submit", (e) => {
  e.preventDefault();
  localStorage.removeItem("cart");
  cart.length = 0;
  renderCart();
  paymentGateway.classList.add("hidden");
  
  // Show alert message
  alert("Payment processed successfully! Thank you for your purchase.");
});

// Initial Render
renderCart();